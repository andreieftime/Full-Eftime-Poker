class Pot:
    def __init__(self, sum, active_players):
        self.sum = sum
        self.active_players = active_players