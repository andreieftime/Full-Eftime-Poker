class Player:
    def __init__(self, holeCards, stack, index, name):
        self.stack = stack
        self.holeCards = holeCards
        self.index = index
        self.name = name